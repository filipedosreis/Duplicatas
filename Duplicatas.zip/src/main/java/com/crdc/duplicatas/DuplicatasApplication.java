package com.crdc.duplicatas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@SpringBootApplication
public class DuplicatasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DuplicatasApplication.class, args);
	}

}
