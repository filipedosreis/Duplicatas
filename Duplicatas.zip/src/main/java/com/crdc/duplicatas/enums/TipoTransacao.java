package com.crdc.duplicatas.enums;

public enum TipoTransacao {

    C, D, T;
}
