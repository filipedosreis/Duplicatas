package com.crdc.duplicatas.enums;

public enum Status {

    success, error;
}
