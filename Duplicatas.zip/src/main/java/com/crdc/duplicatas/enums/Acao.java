package com.crdc.duplicatas.enums;

public enum Acao {

    ARQUIVO_CRIADO,
    ARQUIVO_ATUALIZADO,
    ARQUIVO_VALIDACAO_SUCESSO,
    ARQUIVO_VALIDACAO_ERRO,
    TRANSACAO_AUTORIZADA;
}
