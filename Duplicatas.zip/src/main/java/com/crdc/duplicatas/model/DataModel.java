package com.crdc.duplicatas.model;

import java.util.List;

public class DataModel {

    private List<TransactionModel> transactions;

    public List<TransactionModel> getTransactions() {
        return transactions;
    }

    public void setTransactions(List<TransactionModel> transactions) {
        this.transactions = transactions;
    }
}
