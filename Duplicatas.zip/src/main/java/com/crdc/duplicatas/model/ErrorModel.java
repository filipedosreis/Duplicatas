package com.crdc.duplicatas.model;

public class ErrorModel {

    private int line;
    private String error;

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line = line;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
