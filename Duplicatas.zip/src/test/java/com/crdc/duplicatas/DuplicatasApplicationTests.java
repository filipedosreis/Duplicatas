package com.crdc.duplicatas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DuplicatasApplicationTests {

	@Test
	void contextLoads() {
	}

}
