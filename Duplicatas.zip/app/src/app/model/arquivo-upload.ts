export class ArquivoUploadModel {
    filename!: string;
    fileUri!: string;
}
