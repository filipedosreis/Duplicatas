export class Arquivo {
  id!: number;
  nome!: string;
  enviado!: boolean;
  valido!: boolean;
  criadoEm!: Date;
}
